


shinyServer(
  pageWithSidebar(
    headerPanel("My first Shiny App"),
    
    sidebarPanel("Side bar"),
    
    mainPanel("Main Panel")
  )
  
  
)